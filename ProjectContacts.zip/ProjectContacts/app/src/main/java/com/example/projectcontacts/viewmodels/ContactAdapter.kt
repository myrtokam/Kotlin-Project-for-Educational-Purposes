package com.example.projectcontacts.viewmodels

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.example.projectcontacts.R
import com.example.projectcontacts.database.AppDatabase
import com.example.projectcontacts.database.Contact
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ContactAdapter(private val context: Context, private val contacts: ArrayList<Contact>): BaseAdapter() {
    override fun getCount(): Int {
        return contacts.size
    }

    override fun getItem(position: Int): Any {
        return contacts[position]
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView?: LayoutInflater.from(context).inflate(R.layout.contact_list_item,parent,false)
        val contactIV = view.findViewById<ImageView>(R.id.contactIV)
        val contactNameTV = view.findViewById<TextView>(R.id.contactNameTV)
        val contactPhoneTV = view.findViewById<TextView>(R.id.contactPhoneTV)
        val deleteItemBtn = view.findViewById<Button>(R.id.deleteItemBtn)
        val editItemBtn = view.findViewById<Button>(R.id.editItemBtn)

        contactIV.setImageResource(contacts[position].profileImage)
        contactNameTV.text = contacts[position].name
        contactPhoneTV.text = contacts[position].phone

        deleteItemBtn.setOnClickListener {
            deleteItem(position)
        }

        editItemBtn.setOnClickListener {
            editItem(position)
        }

        return view

    }
    private fun deleteItem(position: Int) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Confirmation Alert")
        builder.setMessage("Are you sure you want to delete this contact?")
        builder.setPositiveButton("Yes") { dialog, which ->
            val contactToDelete = contacts[position]

            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(context)
                db.contactDao().deleteContact(contactToDelete)

                withContext(Dispatchers.Main) {
                    contacts.removeAt(position)
                    notifyDataSetChanged()
                }
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("No") { dialog, which ->
            dialog.dismiss()
        }
        builder.create().show()
    }


    private fun editItem(position: Int) {
        val inflater = LayoutInflater.from(context)
        val myPopupView = inflater.inflate(R.layout.add_contact_layout, null)
        val myWindow = PopupWindow(myPopupView, 1000, 1500, true)
        myWindow.setBackgroundDrawable(ColorDrawable(Color.GRAY))

        val addNameET = myPopupView.findViewById<EditText>(R.id.addNameET)
        val addPhoneET = myPopupView.findViewById<EditText>(R.id.addPhoneET)
        val addPopUpBtn = myPopupView.findViewById<Button>(R.id.addPopUpBtn)

        val currentContact = contacts[position]
        addNameET.setText(currentContact.name)
        addPhoneET.setText(currentContact.phone)

        addPopUpBtn.setOnClickListener {
            val updatedContact = currentContact.copy(
                name = addNameET.text.toString(),
                phone = addPhoneET.text.toString()
            )

            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(context)
                db.contactDao().updateContact(updatedContact)

                withContext(Dispatchers.Main) {
                    contacts[position] = updatedContact
                    notifyDataSetChanged()
                    myWindow.dismiss()
                }
            }
        }
        myWindow.showAtLocation(myPopupView, Gravity.CENTER_VERTICAL , 0 , -200)
    }

}