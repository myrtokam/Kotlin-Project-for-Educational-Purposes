package com.example.projectcontacts.viewmodels

import android.content.Context
import android.util.Log
import com.example.projectcontacts.R
import com.example.projectcontacts.database.AppDatabase
import com.example.projectcontacts.database.Contact
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainModel(var context : Context ) {


    fun insertContact(context: Context, contact: Contact) {
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getDatabase(context)
            db.contactDao().insertContact(contact)
        }
    }

    suspend fun fetchAllContacts(context: Context): List<Contact> {
        val db = AppDatabase.getDatabase(context)
        val contacts = db.contactDao().getAllContacts()
        return contacts
    }


    fun updateContact(context : Context, c : Contact) {
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getDatabase(context)
            db.contactDao().updateContact(c)
        }
    }

    fun deleteContact(context : Context, c : Contact) {
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getDatabase(context)
            db.contactDao().deleteContact(c)
        }
    }

    fun searchContactByName(context : Context, name : String ) {
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getDatabase(context)
            db.contactDao().searchContactByName(name)
            //TODO : WE MUST CHANGE SOMETHING SO THAT UI SHOWS THE SEARCH RESULTS
        }
    }

    fun searchContactById(context : Context, id : Int ) {
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getDatabase(context)
            db.contactDao().searchContactById(id)
            //TODO : WE MUST CHANGE SOMETHING SO THAT UI SHOWS THE SEARCH RESULTS
        }
    }

    fun searchContacts(context: Context, query: String, callback: (List<Contact>) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getDatabase(context)
            val contacts = db.contactDao().searchContacts(query)
            withContext(Dispatchers.Main) {
                callback(contacts)
            }
        }
    }


    fun addContact(
        context: Context,
        name: String,
        phone: String,
        callback: () -> Unit
    ) {
        if (name.isBlank() || phone.isBlank()) {
            throw IllegalArgumentException("Name and phone cannot be blank")
        }

        val newContact = Contact(name = name, phone = phone, profileImage = R.drawable.contact_img)

        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getDatabase(context)
            db.contactDao().insertContact(newContact)
            withContext(Dispatchers.Main) {
                callback()
            }
        }
    }


}